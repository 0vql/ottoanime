module.exports = {
  content: [
    "./pages/**/*.{js,jsx,ts,tsx}",
    "./components/**/*.{js,jsx,ts,tsx}",
    "./redux/**/*.{js,ts,jsx,tsx}",
  ],

  darkMode: "media",
  variants: {
    color: ["responsive", "hover", "focus", "group-hover"],
    borderColor: ["responsive", "hover", "focus", "group-hover"],
  },
  theme: {
    extend: {
      colors: {
        background: "#101010",
        notactive: "#8d8f94",
      },
      width: {
        player: "1024px",
      },
      border: ["hover"],
    },
  },

  variants: {
    extend: {},
    aspectRatio: ["responsive", "hover"],
  },
  plugins: [require("@tailwindcss/aspect-ratio")],
};
