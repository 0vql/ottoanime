export const URL = {
  POPULAR: "https://ottogo.vercel.app/api/popular/",
  RECENT: "https://ottogo.vercel.app/api/latest/",
  DETAILS: "https://ottogo.vercel.app/api/details/",
  EPLINK: "https://ottogo.vercel.app/api/",
  GENRES: "https://ottogo.vercel.app/api/category/",
  SEARCH: "https://ottogo.vercel.app/api/search/",
  GENRES: "https://ottogo.vercel.app/api/category/",
  SEASON: "https://ottogo.vercel.app/api/new-season/",
  MOVIES: "https://ottogo.vercel.app/api/movies/",
};
